export interface AgencyContactConfig {
  name: string;
  shortName: string;
  tagline: string;
  location: string;
  physicalAddress: string;
  phoneDisplay: string;
  phoneRaw: string;
  phoneAltDisplay: string;
  email: string;
  emailQuotes: string;
  workingHours: string;
  defaultWhatsAppMessage: string;
  heroImage: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  iconName: string;
  badge: string;
  targetAudience: string;
  deliverables: string[];
  startingPriceTZS: number;
  deliveryTime: string;
}

export interface DemoProject {
  id: string;
  title: string;
  category: 'hotel' | 'restaurant' | 'business' | 'catalogue' | 'service';
  categoryLabel: string;
  tagline: string;
  description: string;
  image: string;
  mockUrl: string;
  highlights: string[];
  demoFeatures: string[];
  swahiliSummary: string;
  targetIndustry: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  priceTZS: number;
  period?: string;
  popular?: boolean;
  idealFor: string;
  turnaround: string;
  features: string[];
  includedBonuses: string[];
}

export interface FaqItem {
  question: string;
  answer: string;
  swahiliTip?: string;
}
