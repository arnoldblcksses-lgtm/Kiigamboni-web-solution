/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { PortfolioSection } from './components/PortfolioSection';
import { SuccessStoriesSection } from './components/SuccessStoriesSection';
import { PricingSection } from './components/PricingSection';
import { AboutSection } from './components/AboutSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ProjectPreviewModal } from './components/ProjectPreviewModal';
import { PublishingGuideModal } from './components/PublishingGuideModal';
import { MobileQuickBar } from './components/MobileQuickBar';
import { DemoProject } from './types';
import { useTheme } from './hooks/useTheme';

export default function App() {
  const { theme, toggleTheme } = useTheme();
  const [activeProject, setActiveProject] = useState<DemoProject | null>(null);
  const [publishingGuideOpen, setPublishingGuideOpen] = useState(false);
  const [selectedServiceForQuote, setSelectedServiceForQuote] = useState<string>('Business Websites');

  const handleOpenCalculator = () => {
    const pricingEl = document.getElementById('pricing');
    if (pricingEl) {
      pricingEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectServiceForQuote = (serviceTitle: string) => {
    setSelectedServiceForQuote(serviceTitle);
    const contactEl = document.getElementById('contact');
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleRequestSimilarProject = (projectTitle: string) => {
    setSelectedServiceForQuote(`Project similar to: ${projectTitle}`);
    const contactEl = document.getElementById('contact');
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans selection:bg-orange-500 selection:text-white transition-colors duration-200">
      {/* Navigation Header */}
      <Navbar
        theme={theme}
        onToggleTheme={toggleTheme}
        onOpenPublishingGuide={() => setPublishingGuideOpen(true)}
        onOpenQuoteModal={handleOpenCalculator}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero onOpenCalculator={handleOpenCalculator} />

        {/* 5 Core Services */}
        <ServicesSection onSelectServiceForQuote={handleSelectServiceForQuote} />

        {/* Clearly Labelled Demonstration Projects */}
        <PortfolioSection onOpenProject={(project) => setActiveProject(project)} />

        {/* Client Success Stories from Local Businesses in Dar es Salaam */}
        <SuccessStoriesSection onOpenCalculator={handleOpenCalculator} />

        {/* Pricing Section in Tanzanian Shillings & Cost Calculator */}
        <PricingSection onOpenPublishingGuide={() => setPublishingGuideOpen(true)} />

        {/* About Us (Kigamboni, Dar es Salaam, Mobile-First Philosophy) */}
        <AboutSection />

        {/* FAQs */}
        <FaqSection />

        {/* Contact Section with WhatsApp & Validated Proposal Form */}
        <ContactSection initialService={selectedServiceForQuote} />
      </main>

      {/* Footer */}
      <Footer onOpenPublishingGuide={() => setPublishingGuideOpen(true)} />

      {/* Floating Action Bar for Android Smartphones (capped < 15% height) */}
      <MobileQuickBar onOpenCalculator={handleOpenCalculator} />

      {/* Interactive Demonstration Project Modal with Device Switcher */}
      <ProjectPreviewModal
        project={activeProject}
        onClose={() => setActiveProject(null)}
        onRequestSimilar={handleRequestSimilarProject}
      />

      {/* Publishing & Launching Guide Modal */}
      <PublishingGuideModal
        isOpen={publishingGuideOpen}
        onClose={() => setPublishingGuideOpen(false)}
      />
    </div>
  );
}
