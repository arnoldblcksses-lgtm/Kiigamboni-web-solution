import React, { useState } from 'react';
import { 
  X, 
  Globe, 
  Smartphone, 
  Server, 
  PhoneCall, 
  CheckCircle2, 
  Copy, 
  Check, 
  BookOpen, 
  Code2, 
  Layers
} from 'lucide-react';
import { AGENCY_CONFIG } from '../data/agencyData';

interface PublishingGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PublishingGuideModal: React.FC<PublishingGuideModalProps> = ({ isOpen, onClose }) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-navy-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="relative bg-white dark:bg-navy-950 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200 dark:border-navy-800 transition-colors"
        role="dialog"
        aria-modal="true"
        aria-labelledby="guide-title"
      >
        {/* Modal Header */}
        <div className="bg-navy-900 px-6 py-4 text-white flex items-center justify-between border-b border-navy-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-500 rounded-lg text-white">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 id="guide-title" className="text-base sm:text-lg font-bold text-white">
                Website Preview & Publishing Guide
              </h3>
              <p className="text-xs text-slate-300">
                Step-by-step instructions for previewing on mobile and publishing KIGAMBONI WEB SOLUTIONS
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-navy-800 rounded-lg transition-colors cursor-pointer"
            aria-label="Close guide"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Navigation */}
        <div className="bg-slate-100 dark:bg-navy-900 px-6 py-3 border-b border-slate-200 dark:border-navy-800 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {[
            { step: 1, label: '1. Mobile Preview' },
            { step: 2, label: '2. Edit Contacts' },
            { step: 3, label: '3. Domain (.co.tz)' },
            { step: 4, label: '4. Deploy & Host' },
          ].map((item) => (
            <button
              key={item.step}
              onClick={() => setActiveStep(item.step)}
              className={`py-2 px-3 rounded-lg font-bold transition-all text-left flex items-center gap-2 cursor-pointer ${
                activeStep === item.step
                  ? 'bg-navy-900 dark:bg-navy-800 text-white shadow-sm'
                  : 'bg-white dark:bg-navy-950/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-navy-850 border border-slate-200 dark:border-navy-800'
              }`}
            >
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-navy-900/40">
          {/* STEP 1: PREVIEW ON ANDROID PHONES */}
          {activeStep === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-navy-900 dark:text-white font-bold text-base">
                <Smartphone className="w-5 h-5 text-orange-500" />
                <span>How to Preview on Real Android Phones</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Because 80%+ of Tanzanian visitors use smartphones, test this website directly on your Android phone before launch:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
                  <span className="text-xs font-bold text-navy-900 block">Method A: Live Dev URL (Instant)</span>
                  <p className="text-xs text-slate-600">
                    Simply open the AI Studio Development URL or Shared URL in your phone's Chrome or Opera Mini browser. No build steps needed.
                  </p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
                  <span className="text-xs font-bold text-navy-900 block">Method B: Browser DevTools Emulation</span>
                  <p className="text-xs text-slate-600">
                    On your computer browser, press <kbd className="bg-slate-100 border px-1.5 py-0.5 rounded text-[11px]">F12</kbd> or <kbd className="bg-slate-100 border px-1.5 py-0.5 rounded text-[11px]">Ctrl+Shift+M</kbd> to toggle device emulation. Select <strong>Samsung Galaxy</strong> or <strong>Pixel</strong>.
                  </p>
                </div>
              </div>

              <div className="p-4 bg-orange-50 border border-orange-200 rounded-xl text-xs text-orange-950 space-y-1">
                <strong>What to check on mobile:</strong>
                <ul className="list-disc pl-4 space-y-1 mt-1">
                  <li>Tap the WhatsApp button at the bottom—it should open WhatsApp directly with prefilled text.</li>
                  <li>Check that menus, prices in TZS, and contact numbers fit comfortably without horizontal scrolling.</li>
                  <li>Verify that touch targets are large and easy to tap with one thumb.</li>
                </ul>
              </div>
            </div>
          )}

          {/* STEP 2: EDITING PLACEHOLDER CONTACT DETAILS */}
          {activeStep === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-navy-900 font-bold text-base">
                <PhoneCall className="w-5 h-5 text-orange-500" />
                <span>How to Replace Placeholder Contact Details</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                All contact info, prices, and phone numbers are centralized in one single configuration file for easy updating:
              </p>

              <div className="bg-navy-900 text-slate-200 p-4 rounded-xl font-mono text-xs overflow-x-auto relative">
                <div className="flex justify-between items-center mb-2 pb-2 border-b border-navy-800 text-[11px] text-slate-400">
                  <span>File: /src/data/agencyData.ts</span>
                  <button
                    onClick={() => handleCopyCode(
`export const DEFAULT_AGENCY_CONFIG = {
  name: 'KIGAMBONI WEB SOLUTIONS',
  phoneDisplay: '+255 710 841 854', // Configured to your phone
  phoneRaw: '255710841854',        // Configured for direct WhatsApp
  email: 'arnoldblcksses@gmail.com', // Configured to your email
  physicalAddress: 'Ferry Road, Kigamboni, Dar es Salaam',
};`, 'code1')}
                    className="flex items-center gap-1 text-orange-400 hover:text-orange-300"
                  >
                    {copiedCode === 'code1' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode === 'code1' ? 'Copied' : 'Copy snippet'}</span>
                  </button>
                </div>
                <pre>{`export const DEFAULT_AGENCY_CONFIG = {
  name: 'KIGAMBONI WEB SOLUTIONS',
  phoneDisplay: '+255 710 841 854', // Configured to your phone
  phoneRaw: '255710841854',        // Configured for direct WhatsApp
  email: 'arnoldblcksses@gmail.com', // Configured to your email
  physicalAddress: 'Ferry Road, Kigamboni, Dar es Salaam',
};`}</pre>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-400">
                All WhatsApp buttons and quote requests are already routed directly to your WhatsApp (<strong className="text-slate-900 dark:text-white">+255 710 841 854</strong>) and your email (<strong className="text-slate-900 dark:text-white">arnoldblcksses@gmail.com</strong>)!
              </p>
            </div>
          )}

          {/* STEP 3: TANZANIAN DOMAIN SETUP */}
          {activeStep === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-navy-900 font-bold text-base">
                <Globe className="w-5 h-5 text-orange-500" />
                <span>Setting Up a Tanzanian Domain (.co.tz or .com)</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                A localized domain like <strong className="text-navy-900">.co.tz</strong> or international <strong className="text-navy-900">.com</strong> gives your agency immediate authority in East Africa.
              </p>

              <div className="space-y-3">
                <div className="p-3.5 bg-white border border-slate-200 rounded-xl">
                  <span className="text-xs font-bold text-navy-900 block mb-1">1. Register a .co.tz Domain (TZS 25,000 – 45,000 / year)</span>
                  <p className="text-xs text-slate-600">
                    Use accredited Tanzania Network Information Centre (tzNIC) registrars like Extreme Web Technologies, Web Experts Tanzania, or Dudumizi.
                  </p>
                </div>

                <div className="p-3.5 bg-white border border-slate-200 rounded-xl">
                  <span className="text-xs font-bold text-navy-900 block mb-1">2. Point DNS Records</span>
                  <p className="text-xs text-slate-600">
                    Add a CNAME record pointing <code className="bg-slate-100 px-1 py-0.5 rounded">www</code> or an <code className="bg-slate-100 px-1 py-0.5 rounded">A</code> record to your hosting provider IP address. SSL (HTTPS) will provision automatically.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: DEPLOYING & HOSTING */}
          {activeStep === 4 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-navy-900 font-bold text-base">
                <Server className="w-5 h-5 text-orange-500" />
                <span>Publishing & Hosting Recommendations</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                This project is built using modern standard HTML, React, TypeScript, and Vite. You can host it at zero or ultra-low cost:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white dark:bg-navy-900 p-4 rounded-xl border border-slate-200 dark:border-navy-800 space-y-2">
                  <span className="text-xs font-bold text-navy-900 dark:text-white block">1. Download ZIP from AI Studio Interface</span>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    In the top-right corner of the Google AI Studio screen, click the <strong>Export / Code</strong> button and select <strong>"Download as ZIP"</strong> or <strong>"Export to GitHub"</strong>.
                  </p>
                </div>

                <div className="bg-white dark:bg-navy-900 p-4 rounded-xl border border-slate-200 dark:border-navy-800 space-y-2">
                  <span className="text-xs font-bold text-navy-900 dark:text-white block">2. Standard Tanzanian cPanel Hosting</span>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Upload the contents of the generated <code className="bg-slate-100 dark:bg-navy-800 px-1 rounded font-mono">dist/</code> folder into your cPanel <code className="bg-slate-100 dark:bg-navy-800 px-1 rounded font-mono">public_html</code> directory.
                  </p>
                </div>

                <div className="bg-white dark:bg-navy-900 p-4 rounded-xl border border-slate-200 dark:border-navy-800 space-y-2 sm:col-span-2">
                  <span className="text-xs font-bold text-navy-900 dark:text-white block">3. Free 1-Click Cloud Hosting (Vercel / Netlify / Cloudflare)</span>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Export your project to GitHub or drag the downloaded folder into Vercel/Netlify for automated free SSL and continuous hosting.
                  </p>
                </div>
              </div>

              <div className="p-4 bg-navy-900 text-white rounded-xl text-xs space-y-2">
                <span className="font-bold text-orange-400 block">Need assistance launching?</span>
                <p className="text-slate-300">
                  You can contact us anytime via WhatsApp to configure your domain, setup business emails (@kigamboniwebsolutions.co.tz), and launch live to the public.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-white dark:bg-navy-950 px-6 py-4 border-t border-slate-200 dark:border-navy-800 flex items-center justify-between transition-colors">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Kigamboni Web Solutions Deployment Checklist
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-white bg-navy-900 dark:bg-navy-800 hover:bg-navy-800 dark:hover:bg-navy-750 border dark:border-navy-700 rounded-lg cursor-pointer"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
