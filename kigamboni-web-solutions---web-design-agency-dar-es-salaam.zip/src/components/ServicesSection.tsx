import React, { useState } from 'react';
import { 
  Building2, 
  UtensilsCrossed, 
  Hotel, 
  ShoppingBag, 
  ShieldCheck, 
  Check, 
  ArrowRight, 
  MessageSquare,
  Clock,
  ChevronRight
} from 'lucide-react';
import { SERVICES_LIST, AGENCY_CONFIG } from '../data/agencyData';
import { ServiceItem } from '../types';

interface ServicesSectionProps {
  onSelectServiceForQuote: (serviceTitle: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectServiceForQuote }) => {
  const [selectedServiceId, setSelectedServiceId] = useState<string>(SERVICES_LIST[0].id);

  const activeService = SERVICES_LIST.find((s) => s.id === selectedServiceId) || SERVICES_LIST[0];

  const getIcon = (name: string) => {
    switch (name) {
      case 'Building2': return <Building2 className="w-5 h-5" />;
      case 'UtensilsCrossed': return <UtensilsCrossed className="w-5 h-5" />;
      case 'Hotel': return <Hotel className="w-5 h-5" />;
      case 'ShoppingBag': return <ShoppingBag className="w-5 h-5" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5" />;
      default: return <Building2 className="w-5 h-5" />;
    }
  };

  const handleInquireWhatsApp = (service: ServiceItem) => {
    const text = encodeURIComponent(
      `Habari Kigamboni Web Solutions! I am interested in your "${service.title}" package (Starting at TZS ${service.startingPriceTZS.toLocaleString()}). Could you provide more details?`
    );
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="services" className="py-20 lg:py-28 bg-white dark:bg-navy-900 border-b border-slate-200 dark:border-navy-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-3">
            01. Core Capabilities & Services
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-navy-900 dark:text-white tracking-tight mb-4 [text-wrap:balance]">
            Websites Purpose-Built for Your Specific Industry
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
            Every business in Dar es Salaam has unique customers. We do not use cookie-cutter templates; we engineer tailor-made websites that solve your operational bottlenecks and win new customers.
          </p>
        </div>

        {/* Services Master-Detail Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Services Selector Column (Left 5 Cols) */}
          <div className="lg:col-span-5 flex flex-col gap-3">
            {SERVICES_LIST.map((service) => {
              const isSelected = service.id === selectedServiceId;
              return (
                <button
                  key={service.id}
                  onClick={() => setSelectedServiceId(service.id)}
                  className={`w-full text-left p-4 sm:p-5 rounded-xl border transition-all flex items-start gap-4 cursor-pointer ${
                    isSelected
                      ? 'bg-navy-900 dark:bg-navy-800 border-navy-850 dark:border-orange-500/50 text-white shadow-lg shadow-navy-950/20'
                      : 'bg-slate-50 dark:bg-navy-950/60 hover:bg-slate-100 dark:hover:bg-navy-850/80 border-slate-200 dark:border-navy-800 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div
                    className={`p-2.5 rounded-lg shrink-0 mt-0.5 ${
                      isSelected
                        ? 'bg-orange-500 text-white'
                        : 'bg-white dark:bg-navy-900 text-navy-900 dark:text-orange-400 border border-slate-200 dark:border-navy-750'
                    }`}
                  >
                    {getIcon(service.iconName)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <h3 className={`text-base font-bold truncate ${isSelected ? 'text-white' : 'text-navy-900 dark:text-white'}`}>
                        {service.title}
                      </h3>
                      <span className={`text-xs font-semibold tabular-nums shrink-0 ${isSelected ? 'text-orange-400' : 'text-slate-500 dark:text-slate-400'}`}>
                        From TZS {service.startingPriceTZS.toLocaleString()}
                      </span>
                    </div>
                    <p className={`text-xs line-clamp-2 leading-relaxed ${isSelected ? 'text-slate-300' : 'text-slate-500 dark:text-slate-400'}`}>
                      {service.subtitle}
                    </p>
                  </div>
                  <ChevronRight
                    className={`w-5 h-5 shrink-0 self-center transition-transform ${
                      isSelected ? 'text-orange-400 translate-x-1' : 'text-slate-400 dark:text-slate-500'
                    }`}
                  />
                </button>
              );
            })}
          </div>

          {/* Active Service Detailed Card (Right 7 Cols) */}
          <div className="lg:col-span-7 bg-slate-50 dark:bg-navy-950/70 border border-slate-200 dark:border-navy-800 rounded-2xl p-6 sm:p-8 lg:p-10 shadow-sm relative overflow-hidden transition-colors">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-navy-800">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-navy-900 dark:bg-navy-850 text-orange-400 rounded-xl border border-navy-800 dark:border-navy-750">
                  {getIcon(activeService.iconName)}
                </div>
                <div>
                  <h3 className="text-xl sm:text-2xl font-bold text-navy-900 dark:text-white">
                    {activeService.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    {activeService.subtitle}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="block text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400 font-semibold">
                  Investment
                </span>
                <span className="text-xl sm:text-2xl font-extrabold text-navy-900 dark:text-white tabular-nums">
                  TZS {activeService.startingPriceTZS.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Description */}
            <div className="py-6">
              <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed mb-6">
                {activeService.description}
              </p>

              <div className="mb-6 p-4 bg-white dark:bg-navy-900 rounded-xl border border-slate-200/80 dark:border-navy-800">
                <span className="text-xs font-bold text-navy-900 dark:text-white uppercase tracking-wider block mb-1">
                  Target Industries in Tanzania:
                </span>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                  {activeService.targetAudience}
                </p>
              </div>

              {/* What's Included */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">
                  What is included in this package:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
                  {activeService.deliverables.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                      <div className="w-4 h-4 rounded-full bg-orange-100 dark:bg-orange-500/20 text-orange-600 dark:text-orange-400 flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                      <span className="leading-snug">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Meta: Timeline & CTAs */}
              <div className="pt-6 border-t border-slate-200 dark:border-navy-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <Clock className="w-4 h-4 text-orange-500 shrink-0" />
                  <span>Turnaround: <strong className="text-slate-800 dark:text-slate-200">{activeService.deliveryTime}</strong></span>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => onSelectServiceForQuote(activeService.title)}
                    className="px-4 py-2.5 text-xs font-bold text-navy-900 dark:text-slate-200 bg-white dark:bg-navy-900 hover:bg-slate-100 dark:hover:bg-navy-850 border border-slate-300 dark:border-navy-750 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Calculate Quote
                  </button>

                  <button
                    onClick={() => handleInquireWhatsApp(activeService)}
                    className="px-5 py-2.5 text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 active:bg-orange-700 rounded-lg shadow-sm transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Inquire via WhatsApp</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
