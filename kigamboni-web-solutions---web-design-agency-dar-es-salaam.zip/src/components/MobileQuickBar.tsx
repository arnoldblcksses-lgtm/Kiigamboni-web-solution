import React from 'react';
import { MessageSquare, Phone, Calculator } from 'lucide-react';
import { AGENCY_CONFIG } from '../data/agencyData';

interface MobileQuickBarProps {
  onOpenCalculator: () => void;
}

export const MobileQuickBar: React.FC<MobileQuickBarProps> = ({ onOpenCalculator }) => {
  const handleWhatsApp = () => {
    const text = encodeURIComponent(AGENCY_CONFIG.defaultWhatsAppMessage);
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  const handleCall = () => {
    window.location.href = `tel:${AGENCY_CONFIG.phoneDisplay}`;
  };

  return (
    <div className="fixed bottom-0 inset-x-0 z-30 lg:hidden bg-navy-950/95 backdrop-blur-md border-t border-navy-800 p-2.5 px-4 shadow-2xl">
      <div className="max-w-md mx-auto grid grid-cols-3 gap-2 text-xs">
        {/* Call button */}
        <button
          onClick={handleCall}
          className="py-2.5 px-2 bg-navy-850 hover:bg-navy-800 text-slate-200 border border-navy-700 rounded-lg flex flex-col items-center justify-center gap-1 active:scale-95 transition-transform"
        >
          <Phone className="w-3.5 h-3.5 text-orange-400" />
          <span className="text-[11px] font-semibold whitespace-nowrap">Call Us</span>
        </button>

        {/* Quote Calculator */}
        <button
          onClick={onOpenCalculator}
          className="py-2.5 px-2 bg-navy-850 hover:bg-navy-800 text-slate-200 border border-navy-700 rounded-lg flex flex-col items-center justify-center gap-1 active:scale-95 transition-transform"
        >
          <Calculator className="w-3.5 h-3.5 text-orange-400" />
          <span className="text-[11px] font-semibold whitespace-nowrap">TZS Quote</span>
        </button>

        {/* Direct WhatsApp CTA */}
        <button
          onClick={handleWhatsApp}
          className="py-2.5 px-2 bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white font-bold rounded-lg flex flex-col items-center justify-center gap-1 shadow-md active:scale-95 transition-transform"
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span className="text-[11px] font-bold whitespace-nowrap">WhatsApp</span>
        </button>
      </div>
    </div>
  );
};
