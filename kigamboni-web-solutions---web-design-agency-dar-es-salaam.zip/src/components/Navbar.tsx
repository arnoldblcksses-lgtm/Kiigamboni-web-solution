import React, { useState, useEffect } from 'react';
import { MessageSquare, Menu, X, ArrowRight, HelpCircle, Sun, Moon } from 'lucide-react';
import { AGENCY_CONFIG } from '../data/agencyData';
import { Theme } from '../hooks/useTheme';

interface NavbarProps {
  theme: Theme;
  onToggleTheme: () => void;
  onOpenPublishingGuide: () => void;
  onOpenQuoteModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  theme,
  onToggleTheme,
  onOpenPublishingGuide,
  onOpenQuoteModal,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Services', href: '#services' },
    { label: 'Demonstrations', href: '#portfolio' },
    { label: 'Success Stories', href: '#success-stories' },
    { label: 'Pricing (TZS)', href: '#pricing' },
    { label: 'About Us', href: '#about' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleWhatsAppClick = () => {
    const text = encodeURIComponent(AGENCY_CONFIG.defaultWhatsAppMessage);
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <>
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-200 ${
          isScrolled
            ? 'bg-navy-900/95 dark:bg-navy-950/95 backdrop-blur-md border-b border-navy-800 dark:border-navy-900 shadow-md py-3'
            : 'bg-navy-900 dark:bg-navy-950 border-b border-navy-850 dark:border-navy-900 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-8">
            {/* Zone 1: Single text element wordmark */}
            <a
              href="#"
              className="text-lg md:text-xl font-extrabold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2 group"
            >
              <span className="w-2.5 h-6 bg-orange-500 rounded-sm inline-block group-hover:scale-110 transition-transform"></span>
              <span>KIGAMBONI WEB SOLUTIONS</span>
            </a>

            {/* Zone 2: 4-5 clean single-line text navigation links */}
            <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="hover:text-white transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8 decoration-orange-500/60"
                >
                  {link.label}
                </a>
              ))}
              <button
                onClick={onOpenPublishingGuide}
                className="text-slate-400 hover:text-orange-400 text-xs flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 border-l border-navy-700 dark:border-navy-800 pl-4 cursor-pointer"
                title="View Launch & Domain Guide"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Launch Guide</span>
              </button>
            </nav>

            {/* Zone 3: 1 primary action + theme toggle */}
            <div className="flex items-center gap-2.5 shrink-0">
              {/* Theme Toggle Button */}
              <button
                onClick={onToggleTheme}
                aria-label={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
                title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
                className="p-2 text-slate-300 hover:text-white bg-navy-850 dark:bg-navy-900 hover:bg-navy-800 dark:hover:bg-navy-850 border border-navy-750 dark:border-navy-800 rounded-lg transition-colors cursor-pointer flex items-center justify-center"
              >
                {theme === 'light' ? (
                  <Moon className="w-4 h-4 text-orange-400 transition-transform hover:rotate-12" />
                ) : (
                  <Sun className="w-4 h-4 text-amber-300 transition-transform hover:rotate-45" />
                )}
              </button>

              <button
                onClick={handleWhatsAppClick}
                className="hidden sm:flex px-4 py-2.5 text-xs font-semibold text-white bg-orange-500 hover:bg-orange-600 active:bg-orange-700 rounded-lg shadow-sm hover:shadow transition-all items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Chat on WhatsApp</span>
              </button>

              {/* Mobile Drawer Trigger */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-slate-300 hover:text-white hover:bg-navy-800 dark:hover:bg-navy-900 rounded-lg focus:outline-none lg:hidden cursor-pointer"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-navy-950/80 backdrop-blur-sm transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="fixed inset-y-0 right-0 max-w-xs w-full bg-navy-900 dark:bg-navy-950 border-l border-navy-800 shadow-2xl p-6 flex flex-col justify-between overflow-y-auto">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-navy-800">
                <span className="font-bold text-white text-base">KIGAMBONI WEB</span>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 text-slate-400 hover:text-white cursor-pointer"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Theme toggle option inside mobile drawer */}
              <div className="pt-4 pb-2 border-b border-navy-850">
                <button
                  onClick={onToggleTheme}
                  className="w-full py-2.5 px-3 rounded-lg bg-navy-850 dark:bg-navy-900 border border-navy-750 flex items-center justify-between text-xs text-slate-200 cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    {theme === 'light' ? (
                      <Moon className="w-4 h-4 text-orange-400" />
                    ) : (
                      <Sun className="w-4 h-4 text-amber-300" />
                    )}
                    <span>{theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}</span>
                  </span>
                  <span className="text-[11px] font-mono text-orange-400 uppercase font-semibold">
                    {theme}
                  </span>
                </button>
              </div>

              <div className="py-4 flex flex-col gap-3">
                {navLinks.map((link) => (
                  <a
                    key={link.label}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-slate-200 hover:text-orange-400 text-sm font-medium py-2 flex items-center justify-between border-b border-navy-850"
                  >
                    <span>{link.label}</span>
                    <ArrowRight className="w-4 h-4 text-slate-500" />
                  </a>
                ))}
              </div>

              <div className="pt-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenPublishingGuide();
                  }}
                  className="w-full text-left text-xs text-orange-400 hover:text-orange-300 py-2.5 flex items-center gap-2 cursor-pointer"
                >
                  <HelpCircle className="w-4 h-4" />
                  <span>How to Preview & Launch This Site</span>
                </button>
              </div>
            </div>

            <div className="pt-6 border-t border-navy-800 space-y-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  handleWhatsAppClick();
                }}
                className="w-full py-3 px-4 text-sm font-semibold text-white bg-orange-500 hover:bg-orange-600 rounded-lg flex items-center justify-center gap-2 shadow-sm cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat on WhatsApp</span>
              </button>
              <div className="text-center text-xs text-slate-400">
                Dar es Salaam, Tanzania · {AGENCY_CONFIG.phoneDisplay}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
