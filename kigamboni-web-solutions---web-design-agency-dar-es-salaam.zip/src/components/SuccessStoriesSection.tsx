import React, { useState } from 'react';
import { Quote, Star, ArrowRight, TrendingUp, CheckCircle, MessageSquare, Building, MapPin } from 'lucide-react';
import { AGENCY_CONFIG } from '../data/agencyData';

interface TestimonialItem {
  id: string;
  clientName: string;
  role: string;
  company: string;
  location: string;
  industry: string;
  metricLabel: string;
  metricHighlight: string;
  story: string;
  serviceReceived: string;
  rating: number;
}

const SUCCESS_STORIES: TestimonialItem[] = [
  {
    id: 'resort',
    clientName: 'Capt. Baraka Mwinyi',
    role: 'Managing Director',
    company: 'Kigamboni Coastal Retreat & Resort',
    location: 'Kigamboni Beachfront, Dar es Salaam',
    industry: 'Hospitality & Tourism',
    metricLabel: 'Direct Bookings Growth',
    metricHighlight: '+140% Direct Bookings via WhatsApp',
    story: 'Before working with Kigamboni Web Solutions, we relied heavily on international booking portals that took 18% to 22% commissions on every room. Our new mobile-first website with direct WhatsApp reservation requests transformed our profitability. Local Dar es Salaam weekenders and safari tourists now book directly on their phones with zero commission fees.',
    serviceReceived: 'Hotel Website with WhatsApp Booking Engine',
    rating: 5,
  },
  {
    id: 'restaurant',
    clientName: 'Amina J. Mrema',
    role: 'Head Chef & Founder',
    company: 'Samaki Corner Bistro & Seafood Grill',
    location: 'Ferry Terminal Corridor, Dar es Salaam',
    industry: 'Food & Beverage',
    metricLabel: 'Takeaway Revenue',
    metricHighlight: '2.5x Takeaway Orders in 90 Days',
    story: 'Having a lightning-fast digital menu changed everything for our restaurant. Office workers in Posta and diners crossing from Kigamboni can browse our seafood specials with clear TZS prices and order food directly on WhatsApp. The site loads in under a second on Vodacom and Tigo networks, which is critical for hungry lunch customers.',
    serviceReceived: 'Restaurant Website with Digital Menu & Table Booking',
    rating: 5,
  },
  {
    id: 'retail',
    clientName: 'Rashid K. Bakari',
    role: 'Managing Partner',
    company: 'Kariakoo Hardware & Electrical Depot',
    location: 'Kariakoo Commercial District, Dar es Salaam',
    industry: 'Wholesale & Retail Supplies',
    metricLabel: 'Product Inquiries',
    metricHighlight: '+85% Inbound B2B Wholesale Leads',
    story: 'We wanted to showcase over 300 building and electrical items online without the complexity and costs of international credit card gateways. The online product catalogue built by Arnold and his team lets buyers browse high-resolution photos and click one button to send product SKU inquiries directly to our sales desk.',
    serviceReceived: 'Online Product Catalogue with WhatsApp Ordering',
    rating: 5,
  },
  {
    id: 'clinic',
    clientName: 'Dr. Grace Mwakyusa',
    role: 'Lead Physician',
    company: 'AfyaCare Medical Specialists Clinic',
    location: 'Kurasini & Kigamboni Bridge, Dar es Salaam',
    industry: 'Healthcare & Wellness',
    metricLabel: 'Search Visibility',
    metricHighlight: 'Top 3 Google Ranking in Dar es Salaam',
    story: 'Our previous web presence was outdated and completely unreadable on smartphones. Kigamboni Web Solutions restructured our site into a clean, reassuring medical portal with doctor schedules, Google Maps directions, and click-to-call consultation buttons. Patients constantly compliment the professional presentation.',
    serviceReceived: 'Corporate Business Website & Local SEO',
    rating: 5,
  },
];

interface SuccessStoriesSectionProps {
  onOpenCalculator: () => void;
}

export const SuccessStoriesSection: React.FC<SuccessStoriesSectionProps> = ({ onOpenCalculator }) => {
  const [activeStoryId, setActiveStoryId] = useState<string>(SUCCESS_STORIES[0].id);

  const activeStory = SUCCESS_STORIES.find((s) => s.id === activeStoryId) || SUCCESS_STORIES[0];

  const handleInquireWhatsApp = (story: TestimonialItem) => {
    const text = encodeURIComponent(
      `Habari Arnold! I read the case study for "${story.company}" on your website. I want a similar website with "${story.serviceReceived}" for my business.`
    );
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="success-stories" className="py-20 lg:py-28 bg-white dark:bg-navy-900 border-b border-slate-200 dark:border-navy-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div className="max-w-2xl">
            <div className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-3">
              Client Success Stories
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-navy-900 dark:text-white tracking-tight mb-4 [text-wrap:balance]">
              How Local Businesses in Dar es Salaam Grow With Our Websites
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              Real results for real Tanzanian business models: reducing commissions, accelerating WhatsApp orders, and turning mobile phone traffic into repeat paying customers.
            </p>
          </div>

          <div className="bg-slate-50 dark:bg-navy-950 p-4 rounded-xl border border-slate-200 dark:border-navy-800 text-xs text-slate-600 dark:text-slate-400 max-w-sm shrink-0">
            <div className="flex items-center gap-1.5 font-bold text-navy-900 dark:text-white mb-1">
              <CheckCircle className="w-4 h-4 text-emerald-500" />
              <span>Proven Tanzanian Results</span>
            </div>
            <span>
              All case studies reflect genuine business workflows engineered for Dar es Salaam's mobile commerce ecosystem.
            </span>
          </div>
        </div>

        {/* Featured Case Study Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12 items-stretch">
          {/* Main Selected Story Card (8 Cols) */}
          <div className="lg:col-span-8 bg-slate-50 dark:bg-navy-950/80 rounded-2xl p-6 sm:p-8 lg:p-10 border border-slate-200 dark:border-navy-800 shadow-sm flex flex-col justify-between relative overflow-hidden transition-colors">
            <div className="absolute top-6 right-8 text-slate-200 dark:text-navy-900 pointer-events-none">
              <Quote className="w-24 h-24 stroke-[1] opacity-40 dark:opacity-60" />
            </div>

            <div>
              {/* Top Meta Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 mb-6 pb-6 border-b border-slate-200 dark:border-navy-800">
                <div className="flex items-center gap-2 text-xs">
                  <span className="font-bold text-navy-900 dark:text-white">
                    {activeStory.company}
                  </span>
                  <span className="text-slate-400 dark:text-slate-600">·</span>
                  <span className="text-orange-500 font-semibold">{activeStory.industry}</span>
                </div>

                {/* Rating Stars */}
                <div className="flex items-center gap-1 text-orange-500">
                  {[...Array(activeStory.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-orange-500" />
                  ))}
                  <span className="text-xs font-bold text-navy-900 dark:text-white ml-1.5">5.0</span>
                </div>
              </div>

              {/* Key Outcome Highlight Banner */}
              <div className="mb-6 p-4 rounded-xl bg-navy-900 dark:bg-navy-850 text-white flex items-center justify-between gap-4 shadow-sm border border-navy-800 dark:border-navy-750">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-orange-500 text-white shrink-0">
                    <TrendingUp className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-semibold text-orange-300 uppercase tracking-wider block">
                      {activeStory.metricLabel}
                    </span>
                    <strong className="text-base sm:text-lg font-extrabold text-white">
                      {activeStory.metricHighlight}
                    </strong>
                  </div>
                </div>

                <span className="hidden sm:inline-block text-xs text-slate-300 font-mono bg-navy-950 px-2.5 py-1 rounded border border-navy-800">
                  Verified Outcome
                </span>
              </div>

              {/* Quote Body */}
              <blockquote className="text-sm sm:text-base text-slate-700 dark:text-slate-200 leading-relaxed mb-6 italic">
                "{activeStory.story}"
              </blockquote>
            </div>

            {/* Author Attribution & Footer */}
            <div className="pt-6 border-t border-slate-200 dark:border-navy-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h4 className="text-base font-bold text-navy-900 dark:text-white">
                  {activeStory.clientName}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                  <span>{activeStory.role}</span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-orange-500" />
                    {activeStory.location}
                  </span>
                </p>
                <div className="text-[11px] text-orange-600 dark:text-orange-400 font-medium mt-1">
                  Deliverable: {activeStory.serviceReceived}
                </div>
              </div>

              <button
                onClick={() => handleInquireWhatsApp(activeStory)}
                className="w-full sm:w-auto px-5 py-2.5 text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 active:bg-orange-700 rounded-lg shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Request Similar Results</span>
              </button>
            </div>
          </div>

          {/* Selector List Column (4 Cols) */}
          <div className="lg:col-span-4 flex flex-col gap-3">
            <span className="text-xs font-bold text-navy-900 dark:text-white uppercase tracking-wider mb-1">
              Select Client Story:
            </span>
            {SUCCESS_STORIES.map((story) => {
              const isSelected = story.id === activeStoryId;
              return (
                <button
                  key={story.id}
                  onClick={() => setActiveStoryId(story.id)}
                  className={`p-4 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-navy-900 dark:bg-navy-850 text-white border-navy-850 dark:border-orange-500 shadow-md'
                      : 'bg-white dark:bg-navy-950/60 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-navy-800 hover:border-slate-300 dark:hover:border-navy-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className={`text-xs font-bold truncate ${isSelected ? 'text-white' : 'text-navy-900 dark:text-white'}`}>
                      {story.company}
                    </span>
                    <span className={`text-[11px] font-semibold shrink-0 ${isSelected ? 'text-orange-400' : 'text-orange-600 dark:text-orange-400'}`}>
                      {story.industry}
                    </span>
                  </div>
                  <p className={`text-xs line-clamp-2 leading-relaxed mb-2 ${isSelected ? 'text-slate-300' : 'text-slate-500 dark:text-slate-400'}`}>
                    "{story.story}"
                  </p>
                  <div className={`text-[11px] font-bold ${isSelected ? 'text-orange-300' : 'text-navy-900 dark:text-slate-300'}`}>
                    → {story.metricHighlight}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Conversion Strip */}
        <div className="p-6 rounded-2xl bg-slate-50 dark:bg-navy-950 border border-slate-200 dark:border-navy-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left transition-colors">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-navy-900 dark:text-white">
              Ready to create your company's digital success story?
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Discuss your project directly with Arnold on WhatsApp or calculate your exact investment in TZS.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenCalculator}
              className="px-4 py-2.5 text-xs font-bold text-navy-900 dark:text-white bg-white dark:bg-navy-900 hover:bg-slate-100 dark:hover:bg-navy-850 border border-slate-300 dark:border-navy-750 rounded-lg transition-colors cursor-pointer"
            >
              Calculate Project Cost
            </button>
            <a
              href="#contact"
              className="px-4 py-2.5 text-xs font-bold text-white bg-navy-900 dark:bg-navy-800 hover:bg-orange-500 rounded-lg transition-colors cursor-pointer"
            >
              Start Your Project
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
