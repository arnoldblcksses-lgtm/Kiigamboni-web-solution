import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageSquare } from 'lucide-react';
import { FAQS_LIST, AGENCY_CONFIG } from '../data/agencyData';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const handleCustomQuestionWhatsApp = () => {
    const text = encodeURIComponent('Habari Kigamboni Web Solutions! I have a specific question about getting a website for my business.');
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section className="py-20 lg:py-24 bg-white dark:bg-navy-900 border-b border-slate-200 dark:border-navy-800 transition-colors">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-2">
            Clear Answers
          </div>
          <h2 className="text-3xl font-extrabold text-navy-900 dark:text-white tracking-tight mb-3">
            Frequently Asked Questions
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 max-w-xl mx-auto">
            Everything you need to know about working with our web design agency in Dar es Salaam.
          </p>
        </div>

        <div className="space-y-3">
          {FAQS_LIST.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="border border-slate-200 dark:border-navy-800 rounded-xl overflow-hidden transition-all bg-slate-50 dark:bg-navy-950/70"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer focus:outline-none hover:bg-slate-100/60 dark:hover:bg-navy-850/60 transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm sm:text-base font-bold text-navy-900 dark:text-white">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-500 dark:text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-orange-500' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-4 sm:px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed border-t border-slate-200/60 dark:border-navy-800 bg-white dark:bg-navy-950/90">
                    <p className="mb-2">{faq.answer}</p>
                    {faq.swahiliTip && (
                      <div className="p-2.5 bg-orange-50/70 dark:bg-orange-500/15 border border-orange-100 dark:border-orange-500/30 rounded-lg text-xs text-orange-950 dark:text-orange-200 font-medium">
                        💡 <strong>Kidokezo:</strong> {faq.swahiliTip}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-10 p-5 rounded-xl bg-slate-50 dark:bg-navy-950/60 border border-slate-200 dark:border-navy-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <div className="text-xs font-bold text-navy-900 dark:text-white">Have a unique business requirement?</div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Ask us directly on WhatsApp and receive a response within minutes.</div>
          </div>
          <button
            onClick={handleCustomQuestionWhatsApp}
            className="px-4 py-2 text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 rounded-lg flex items-center gap-2 whitespace-nowrap cursor-pointer shadow-sm"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Ask on WhatsApp</span>
          </button>
        </div>
      </div>
    </section>
  );
};
