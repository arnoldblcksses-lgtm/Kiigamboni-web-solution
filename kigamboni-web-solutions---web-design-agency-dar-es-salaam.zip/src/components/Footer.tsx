import React from 'react';
import { MessageSquare, Mail, Phone, MapPin, ArrowUp, HelpCircle } from 'lucide-react';
import { AGENCY_CONFIG } from '../data/agencyData';

interface FooterProps {
  onOpenPublishingGuide: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenPublishingGuide }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(AGENCY_CONFIG.defaultWhatsAppMessage);
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <footer className="bg-navy-950 text-slate-400 border-t border-navy-850 pt-16 pb-24 lg:pb-16 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-navy-850">
          {/* Brand & Mission (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <a
              href="#"
              className="text-lg font-extrabold text-white tracking-tight flex items-center gap-2"
            >
              <span className="w-2.5 h-6 bg-orange-500 rounded-sm inline-block"></span>
              <span>KIGAMBONI WEB SOLUTIONS</span>
            </a>
            <p className="text-slate-400 leading-relaxed max-w-sm">
              Professional web design and development agency in Kigamboni, Dar es Salaam, Tanzania. We build high-converting business, hotel, restaurant, and catalogue websites that turn mobile visitors into paying customers.
            </p>
            <div className="flex items-center gap-2 text-slate-400 pt-1">
              <MapPin className="w-3.5 h-3.5 text-orange-400" />
              <span>Kigamboni Ferry Road · Dar es Salaam, Tanzania</span>
            </div>
          </div>

          {/* Quick Nav Links */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Core Services
            </span>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#services" className="hover:text-white transition-colors">Business Websites</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Restaurant & Café Menus</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Hotel & Resort Bookings</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Online Catalogues</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Website Maintenance</a></li>
            </ul>
          </div>

          {/* Demonstration Prototypes */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Demonstration Projects
            </span>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#portfolio" className="hover:text-white transition-colors">Beachfront Resort Demo</a></li>
              <li><a href="#portfolio" className="hover:text-white transition-colors">Zanzibar Bistro Demo</a></li>
              <li><a href="#success-stories" className="hover:text-white transition-colors">Client Success Stories</a></li>
              <li><a href="#pricing" className="hover:text-white transition-colors">Pricing in TZS</a></li>
            </ul>
          </div>

          {/* Direct Assistance */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Client Support
            </span>
            <div className="space-y-2 text-slate-400">
              <button
                onClick={handleWhatsApp}
                className="w-full text-left flex items-center gap-2 hover:text-white transition-colors cursor-pointer text-orange-400"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp: {AGENCY_CONFIG.phoneDisplay}</span>
              </button>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-slate-500" />
                <span className="truncate">{AGENCY_CONFIG.email}</span>
              </div>
              <div className="pt-2">
                <button
                  onClick={onOpenPublishingGuide}
                  className="px-3 py-1.5 bg-navy-850 hover:bg-navy-800 text-orange-300 rounded border border-navy-700 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Website Publishing Guide</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500">
          <div className="text-center sm:text-left">
            © {new Date().getFullYear()} KIGAMBONI WEB SOLUTIONS. All rights reserved. Kigamboni, Dar es Salaam, Tanzania.
          </div>

          <div className="flex items-center gap-6">
            <span className="text-slate-500">Android & Mobile-First Web Architecture</span>
            <button
              onClick={scrollToTop}
              className="p-2 bg-navy-850 hover:bg-navy-800 text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
              aria-label="Scroll to top of page"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
