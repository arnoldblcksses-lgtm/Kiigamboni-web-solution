import React, { useState } from 'react';
import { ExternalLink, Smartphone, Sparkles, Check, ArrowRight } from 'lucide-react';
import { DEMO_PROJECTS } from '../data/agencyData';
import { DemoProject } from '../types';

interface PortfolioSectionProps {
  onOpenProject: (project: DemoProject) => void;
}

export const PortfolioSection: React.FC<PortfolioSectionProps> = ({ onOpenProject }) => {
  const [filter, setFilter] = useState<string>('all');

  const filteredProjects = filter === 'all'
    ? DEMO_PROJECTS
    : DEMO_PROJECTS.filter((p) => p.category === filter);

  return (
    <section id="portfolio" className="py-20 lg:py-28 bg-slate-50 dark:bg-navy-950 border-b border-slate-200 dark:border-navy-850 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <div className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-3">
              02. Proof of Craft & Prototypes
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-navy-900 dark:text-white tracking-tight mb-3 [text-wrap:balance]">
              Demonstration Projects & Interactive Concepts
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              Explore interactive prototypes engineered to show how real hotels, restaurants, shops, and firms in Dar es Salaam convert visitors into direct bookings and WhatsApp inquiries.
            </p>
          </div>

          {/* Clean Notice (Honoring user requirement: clearly labelled demonstration projects) */}
          <div className="bg-white dark:bg-navy-900 border border-slate-200 dark:border-navy-800 p-3.5 rounded-xl text-xs text-slate-600 dark:text-slate-400 max-w-sm shrink-0">
            <strong className="text-navy-900 dark:text-white font-bold block mb-0.5">Transparency Guarantee:</strong>
            These are fully functioning demonstration prototypes designed by our studio to show our work quality. We never fabricate client testimonials.
          </div>
        </div>

        {/* Filter Segmented Control */}
        <div className="flex items-center gap-1.5 p-1.5 bg-slate-200/70 dark:bg-navy-900 border border-transparent dark:border-navy-800 rounded-xl max-w-fit overflow-x-auto mb-10 text-xs">
          {[
            { id: 'all', label: 'All Demonstration Projects' },
            { id: 'hotel', label: 'Hotel & Resort' },
            { id: 'restaurant', label: 'Restaurant & Café' },
            { id: 'catalogue', label: 'Online Catalogue' },
            { id: 'business', label: 'Corporate Business' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id)}
              className={`px-3.5 py-2 font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                filter === tab.id
                  ? 'bg-white dark:bg-navy-800 text-navy-900 dark:text-white font-bold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-navy-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="bg-white dark:bg-navy-900 rounded-2xl overflow-hidden border border-slate-200 dark:border-navy-800 hover:border-slate-300 dark:hover:border-navy-700 shadow-sm hover:shadow-md transition-all flex flex-col group"
            >
              {/* Media Container with clean header bar */}
              <div className="relative bg-slate-900 overflow-hidden">
                <div className="bg-navy-900 px-4 py-2 border-b border-navy-800 flex items-center justify-between text-[11px] text-slate-300">
                  <span className="font-mono truncate">{project.mockUrl}</span>
                  <span className="text-orange-400 font-semibold uppercase tracking-wider shrink-0">
                    {project.categoryLabel}
                  </span>
                </div>

                <div className="relative h-60 sm:h-72 overflow-hidden bg-slate-950">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/20 to-transparent" />

                  {/* Visual tag over image */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-white">
                    <div>
                      <div className="text-xs text-orange-400 font-semibold mb-0.5">
                        Interactive Concept
                      </div>
                      <h3 className="text-lg sm:text-xl font-bold leading-snug">
                        {project.title}
                      </h3>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-5">
                    {project.description}
                  </p>

                  {/* Highlights with clean typographic checkmarks */}
                  <div className="space-y-2 mb-6">
                    <span className="text-xs font-bold text-navy-900 dark:text-white uppercase tracking-wider block">
                      Demonstration Features:
                    </span>
                    {project.highlights.slice(0, 3).map((item, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                        <Check className="w-3.5 h-3.5 text-orange-500 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bottom Card Action */}
                <div className="pt-4 border-t border-slate-100 dark:border-navy-800 flex items-center justify-between gap-3">
                  <span className="text-xs text-slate-500 dark:text-slate-400 font-medium truncate">
                    {project.targetIndustry}
                  </span>

                  <button
                    onClick={() => onOpenProject(project)}
                    className="px-4 py-2 text-xs font-bold text-white bg-navy-900 dark:bg-navy-800 hover:bg-orange-500 dark:hover:bg-orange-500 active:bg-orange-600 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 shadow-sm border border-transparent dark:border-navy-700"
                  >
                    <span>Test Interactive Demo</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
