import React, { useState } from 'react';
import { 
  X, 
  ExternalLink, 
  Smartphone, 
  Monitor, 
  MessageSquare, 
  Check, 
  Sparkles,
  ShoppingBag,
  UtensilsCrossed,
  Hotel,
  Building2,
  Calendar,
  Send
} from 'lucide-react';
import { DemoProject } from '../types';
import { AGENCY_CONFIG } from '../data/agencyData';

interface ProjectPreviewModalProps {
  project: DemoProject | null;
  onClose: () => void;
  onRequestSimilar: (projectTitle: string) => void;
}

export const ProjectPreviewModal: React.FC<ProjectPreviewModalProps> = ({
  project,
  onClose,
  onRequestSimilar,
}) => {
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'mobile'>('desktop');
  const [activeTab, setActiveTab] = useState<'overview' | 'interactive' | 'specifications'>('overview');

  // Interactive demo states
  const [checkInDate, setCheckInDate] = useState('2026-11-15');
  const [guests, setGuests] = useState('2 Adults');
  const [reservedAlert, setReservedAlert] = useState<string | null>(null);

  // Restaurant demo state
  const [cartItems, setCartItems] = useState<{ name: string; price: number }[]>([
    { name: 'Swahili Coconut Seafood Curry', price: 28000 },
    { name: 'Charcoal Grilled Jumbo Prawns', price: 34000 },
  ]);

  // Catalogue demo state
  const [selectedProduct, setSelectedProduct] = useState({
    name: 'Handcrafted Zanzibar Teak Coffee Table',
    sku: 'TZ-TEAK-09',
    price: 380000,
    status: 'In Stock in Kigamboni Workshop',
  });

  if (!project) return null;

  const handleWhatsAppBooking = () => {
    const message = encodeURIComponent(
      `Habari Kigamboni Web Solutions! I tested your demonstration project "${project.title}" on your agency website. I would like a quote to build a similar website for my business.`
    );
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${message}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-navy-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 animate-in fade-in duration-200">
      <div 
        className="relative bg-white dark:bg-navy-950 rounded-2xl shadow-2xl max-w-5xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200 dark:border-navy-800 transition-colors"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        {/* Top Control Bar */}
        <div className="bg-navy-900 px-4 sm:px-6 py-3.5 text-white flex items-center justify-between gap-4 border-b border-navy-800">
          <div className="flex items-center gap-3 min-w-0">
            <span className="text-xs font-bold text-orange-400 uppercase tracking-wider shrink-0 bg-navy-800 px-2.5 py-1 rounded">
              Interactive Prototype
            </span>
            <h3 id="modal-title" className="text-sm sm:text-base font-bold text-white truncate">
              {project.title}
            </h3>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Device Switcher */}
            <div className="hidden sm:flex items-center gap-1 bg-navy-950 p-1 rounded-lg border border-navy-800 text-xs">
              <button
                onClick={() => setDeviceMode('desktop')}
                className={`px-2.5 py-1 rounded flex items-center gap-1.5 transition-colors cursor-pointer ${
                  deviceMode === 'desktop' ? 'bg-orange-500 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Desktop</span>
              </button>
              <button
                onClick={() => setDeviceMode('mobile')}
                className={`px-2.5 py-1 rounded flex items-center gap-1.5 transition-colors cursor-pointer ${
                  deviceMode === 'mobile' ? 'bg-orange-500 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Android Phone</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-navy-800 rounded-lg transition-colors cursor-pointer"
              aria-label="Close demonstration modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Sub-navigation tabs */}
        <div className="bg-slate-100 dark:bg-navy-900 px-4 sm:px-6 py-2.5 border-b border-slate-200 dark:border-navy-800 flex items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-white dark:bg-navy-800 text-navy-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Concept Overview
            </button>
            <button
              onClick={() => setActiveTab('interactive')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'interactive'
                  ? 'bg-white dark:bg-navy-800 text-orange-600 dark:text-orange-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-orange-500" />
              <span>Interactive Simulator</span>
            </button>
            <button
              onClick={() => setActiveTab('specifications')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                activeTab === 'specifications'
                  ? 'bg-white dark:bg-navy-800 text-navy-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Technical Specs
            </button>
          </div>

          <span className="hidden md:inline text-slate-500 font-mono text-[11px]">
            {project.mockUrl}
          </span>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-slate-50">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Device Frame Preview */}
              <div className={`mx-auto transition-all duration-300 ${deviceMode === 'mobile' ? 'max-w-sm' : 'w-full'}`}>
                <div className="bg-slate-900 rounded-xl overflow-hidden shadow-xl border border-slate-300 relative group">
                  {/* Browser or Phone Header Chrome */}
                  <div className="bg-slate-800 px-4 py-2 flex items-center gap-2 text-xs text-slate-400">
                    <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-red-400/80" />
                      <div className="w-2.5 h-2.5 rounded-full bg-amber-400/80" />
                      <div className="w-2.5 h-2.5 rounded-full bg-green-400/80" />
                    </div>
                    <div className="flex-1 bg-slate-900/80 text-[11px] font-mono text-slate-300 px-3 py-0.5 rounded text-center truncate">
                      https://{project.mockUrl}
                    </div>
                  </div>

                  {/* Screenshot / Mock View */}
                  <div className="relative">
                    <img
                      src={project.image}
                      alt={project.title}
                      className={`w-full object-cover ${deviceMode === 'mobile' ? 'h-[460px]' : 'h-[360px] sm:h-[420px]'}`}
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-950/80 via-transparent to-transparent flex items-end p-6">
                      <div className="text-white">
                        <span className="text-xs uppercase tracking-wider font-semibold text-orange-400 block mb-1">
                          {project.categoryLabel}
                        </span>
                        <h4 className="text-xl sm:text-2xl font-bold">{project.title}</h4>
                        <p className="text-xs sm:text-sm text-slate-200 mt-1 max-w-xl">
                          {project.tagline}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Explanatory Description */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-2">
                <div className="md:col-span-7 space-y-4">
                  <h4 className="text-sm font-bold text-navy-900 uppercase tracking-wider">
                    Demonstration Purpose & Strategy
                  </h4>
                  <p className="text-sm text-slate-700 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="p-3.5 bg-orange-50 border border-orange-200 rounded-xl text-xs text-orange-950">
                    <strong className="block font-bold mb-1">Swahili Summary / Muhtasari:</strong>
                    {project.swahiliSummary}
                  </div>
                </div>

                <div className="md:col-span-5 bg-white p-5 rounded-xl border border-slate-200 space-y-4">
                  <h4 className="text-xs font-bold text-navy-900 uppercase tracking-wider">
                    Key Conversion Features Included:
                  </h4>
                  <ul className="space-y-2.5 text-xs text-slate-700">
                    {project.highlights.map((highlight, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-orange-500 shrink-0 mt-0.5" />
                        <span className="leading-tight">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500">
                    Industry focus: <strong className="text-slate-800">{project.targetIndustry}</strong>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Interactive Feature Simulator */}
          {activeTab === 'interactive' && (
            <div className="space-y-6">
              <div className="p-4 bg-white rounded-xl border border-slate-200">
                <span className="text-xs font-bold text-orange-600 uppercase tracking-wider block mb-1">
                  Test-Drive Real Client Workflows
                </span>
                <p className="text-xs sm:text-sm text-slate-600">
                  Experience how your real customers in Dar es Salaam interact with booking and order requests without needing expensive credit card software.
                </p>
              </div>

              {/* HOTEL DEMO INTERACTIVE SIMULATOR */}
              {project.category === 'hotel' && (
                <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-5">
                  <div className="flex items-center gap-2 text-sm font-bold text-navy-900">
                    <Hotel className="w-4 h-4 text-orange-500" />
                    <span>Direct WhatsApp Room Booking Simulation</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Check-in Date</label>
                      <input
                        type="date"
                        value={checkInDate}
                        onChange={(e) => setCheckInDate(e.target.value)}
                        className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Guests / Room</label>
                      <select
                        value={guests}
                        onChange={(e) => setGuests(e.target.value)}
                        className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none"
                      >
                        <option>1 Adult</option>
                        <option>2 Adults (1 Room)</option>
                        <option>Family (2 Adults + 2 Kids)</option>
                        <option>Group (4+ Guests)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Selected Suite</label>
                      <div className="text-xs font-bold text-navy-900 p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                        Oceanview Deluxe (TZS 220,000 / Night)
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="text-xs text-slate-600">
                      Simulated Client Action: When clicked on your live website, this automatically opens WhatsApp with:
                      <code className="block mt-1 p-2 bg-white rounded border text-[11px] text-slate-800">
                        "Habari! I would like to reserve Oceanview Deluxe from {checkInDate} for {guests}."
                      </code>
                    </div>
                    <button
                      onClick={() => {
                        setReservedAlert('WhatsApp booking message dispatched! This gives your hotel instant direct bookings with 0% commission.');
                        setTimeout(() => setReservedAlert(null), 4000);
                      }}
                      className="px-4 py-2.5 text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 rounded-lg whitespace-nowrap cursor-pointer flex items-center gap-1.5"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Test WhatsApp Inquiry</span>
                    </button>
                  </div>

                  {reservedAlert && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg font-medium">
                      ✓ {reservedAlert}
                    </div>
                  )}
                </div>
              )}

              {/* RESTAURANT DEMO INTERACTIVE SIMULATOR */}
              {project.category === 'restaurant' && (
                <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-5">
                  <div className="flex items-center gap-2 text-sm font-bold text-navy-900">
                    <UtensilsCrossed className="w-4 h-4 text-orange-500" />
                    <span>Interactive Restaurant Menu & Takeaway Bag</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { name: 'Swahili Coconut Seafood Curry', price: 28000, desc: 'Fresh Indian Ocean fish in spiced coconut gravy' },
                      { name: 'Charcoal Grilled Jumbo Prawns', price: 34000, desc: 'Served with garlic butter and cassava chips' },
                      { name: 'Kigamboni Beach Nyama Choma', price: 25000, desc: 'Tender spiced goat meat with kachumbari' },
                      { name: 'Fresh Tropical Passion Juice', price: 6000, desc: '100% natural Dar es Salaam fruit blend' },
                    ].map((dish, i) => (
                      <div key={i} className="p-3 rounded-lg border border-slate-200 hover:border-orange-300 flex items-center justify-between gap-2">
                        <div>
                          <div className="text-xs font-bold text-navy-900">{dish.name}</div>
                          <div className="text-[11px] text-slate-500">{dish.desc}</div>
                          <div className="text-xs font-bold text-orange-600 mt-0.5">TZS {dish.price.toLocaleString()}</div>
                        </div>
                        <button
                          onClick={() => {
                            setCartItems([...cartItems, { name: dish.name, price: dish.price }]);
                          }}
                          className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-orange-500 hover:text-white rounded transition-colors cursor-pointer"
                        >
                          + Add
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="text-xs text-slate-700">
                      Total in Demo Order: <strong>TZS {cartItems.reduce((acc, cur) => acc + cur.price, 0).toLocaleString()}</strong> ({cartItems.length} items)
                    </div>
                    <button
                      onClick={() => {
                        setReservedAlert('Order sent to Restaurant WhatsApp! The kitchen receives exact dishes & delivery address instantly.');
                        setTimeout(() => setReservedAlert(null), 4000);
                      }}
                      className="px-4 py-2.5 text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 rounded-lg whitespace-nowrap cursor-pointer flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Send Order to WhatsApp</span>
                    </button>
                  </div>

                  {reservedAlert && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg font-medium">
                      ✓ {reservedAlert}
                    </div>
                  )}
                </div>
              )}

              {/* CATALOGUE OR BUSINESS DEMO INTERACTIVE SIMULATOR */}
              {(project.category === 'catalogue' || project.category === 'business') && (
                <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-5">
                  <div className="flex items-center gap-2 text-sm font-bold text-navy-900">
                    <ShoppingBag className="w-4 h-4 text-orange-500" />
                    <span>Product Item & WhatsApp Lead Simulation</span>
                  </div>

                  <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="text-sm font-bold text-navy-900 mb-1">{selectedProduct.name}</div>
                    <div className="text-xs text-slate-500 mb-2">Item Code: {selectedProduct.sku} · {selectedProduct.status}</div>
                    <div className="text-base font-extrabold text-navy-900 mb-4">
                      TZS {selectedProduct.price.toLocaleString()}
                    </div>

                    <button
                      onClick={() => {
                        setReservedAlert(`Inquiry dispatched for "${selectedProduct.name}"! Client gets immediate WhatsApp message.`);
                        setTimeout(() => setReservedAlert(null), 4000);
                      }}
                      className="px-4 py-2 text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 rounded-lg flex items-center gap-2 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Simulate "Order on WhatsApp"</span>
                    </button>
                  </div>

                  {reservedAlert && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg font-medium">
                      ✓ {reservedAlert}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Technical Specifications Tab */}
          {activeTab === 'specifications' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-5 rounded-xl border border-slate-200">
                  <h5 className="text-xs font-bold text-navy-900 uppercase tracking-wider mb-3">
                    Performance & Mobile Standards
                  </h5>
                  <div className="space-y-2 text-xs text-slate-700">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span>Android Speed Score:</span>
                      <strong className="text-emerald-600">95 / 100 on Mobile Data</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span>Average Page Weight:</span>
                      <strong className="text-slate-900">&lt; 850 KB (Light on Bundles)</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span>WhatsApp Link Latency:</span>
                      <strong className="text-slate-900">&lt; 150ms Instant Handshake</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span>Supported Browsers:</span>
                      <strong className="text-slate-900">Chrome, Safari, Opera Mini, Edge</strong>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-xl border border-slate-200">
                  <h5 className="text-xs font-bold text-navy-900 uppercase tracking-wider mb-3">
                    Tanzanian Business Integrations
                  </h5>
                  <div className="space-y-2 text-xs text-slate-700">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span>WhatsApp Direct Checkout:</span>
                      <strong className="text-emerald-600">Native API (No 3rd-party fees)</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span>Local SEO Schema:</span>
                      <strong className="text-slate-900">GeoCoordinates Dar es Salaam</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span>Domain Readiness:</span>
                      <strong className="text-slate-900">.co.tz and .com compatible</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span>Zero Monthly Lock-in:</span>
                      <strong className="text-emerald-600">No Shopify/Wix recurring fees</strong>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-100 rounded-xl text-xs text-slate-600">
                Note: This is a demonstration project created by Kigamboni Web Solutions to exhibit layout, speed, and conversion mechanics. No real client customer data is stored or claimed.
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom CTA Bar */}
        <div className="bg-white dark:bg-navy-950 px-4 sm:px-6 py-4 border-t border-slate-200 dark:border-navy-800 flex flex-col sm:flex-row items-center justify-between gap-3 transition-colors">
          <div className="text-xs text-slate-500 dark:text-slate-400 text-center sm:text-left">
            Ready for a custom website like <strong className="text-slate-800 dark:text-white">{project.title}</strong>?
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={() => {
                onClose();
                onRequestSimilar(project.title);
              }}
              className="flex-1 sm:flex-none px-4 py-2.5 text-xs font-bold text-navy-900 dark:text-slate-200 bg-slate-100 dark:bg-navy-850 hover:bg-slate-200 dark:hover:bg-navy-800 border border-transparent dark:border-navy-700 rounded-lg transition-colors cursor-pointer"
            >
              Get Custom Quote
            </button>
            <button
              onClick={handleWhatsAppBooking}
              className="flex-1 sm:flex-none px-5 py-2.5 text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 rounded-lg shadow-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Discuss on WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
