import React, { useState } from 'react';
import { 
  MessageSquare, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Copy, 
  Check, 
  Send, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { AGENCY_CONFIG } from '../data/agencyData';

interface ContactSectionProps {
  initialService?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ initialService }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    businessName: '',
    phone: '',
    service: initialService || 'Business Websites',
    budgetRange: 'TZS 450,000 – TZS 950,000',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(label);
    setTimeout(() => setCopiedField(null), 2500);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.phone) return;
    setSubmitted(true);
  };

  const handleForwardToWhatsApp = () => {
    const text = encodeURIComponent(
      `Habari Kigamboni Web Solutions!\n\nNew Website Inquiry:\n- Name: ${formData.fullName}\n- Business: ${formData.businessName || 'N/A'}\n- Phone: ${formData.phone}\n- Service: ${formData.service}\n- Budget: ${formData.budgetRange}\n- Details: ${formData.message || 'Looking for an initial discussion.'}`
    );
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  const handleSendEmail = () => {
    const subject = encodeURIComponent(`New Website Proposal Inquiry: ${formData.fullName} (${formData.service})`);
    const body = encodeURIComponent(
      `Habari Arnold,\n\nHere are the inquiry details from your website:\n\n- Client Name: ${formData.fullName}\n- Business: ${formData.businessName || 'Not specified'}\n- Phone/WhatsApp: ${formData.phone}\n- Selected Service: ${formData.service}\n- Budget: ${formData.budgetRange}\n\nMessage/Requirements:\n${formData.message || 'Ready to discuss requirements.'}\n\nBest regards.`
    );
    window.location.href = `mailto:${AGENCY_CONFIG.email}?subject=${subject}&body=${body}`;
  };

  const handleDirectWhatsApp = () => {
    const text = encodeURIComponent(AGENCY_CONFIG.defaultWhatsAppMessage);
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contact" className="py-20 lg:py-28 bg-navy-900 dark:bg-navy-950 text-white relative overflow-hidden transition-colors">
      {/* Background glow */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section Heading */}
        <div className="max-w-3xl mb-14">
          <div className="text-xs font-bold tracking-widest text-orange-400 uppercase mb-3">
            05. Start Your Project
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 [text-wrap:balance]">
            Let’s Build a Website That Attracts Paying Clients
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Reach out directly via WhatsApp for the fastest response, or complete our quick inquiry form below. We will analyze your business requirements and provide a free proposal with zero obligation.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Direct Contact & WhatsApp Hub */}
          <div className="lg:col-span-5 space-y-6">
            {/* Prominent WhatsApp Card */}
            <div className="p-6 sm:p-7 rounded-2xl bg-navy-850 dark:bg-navy-900 border border-navy-750 dark:border-navy-800 shadow-xl relative overflow-hidden">
              <div className="flex items-center justify-between gap-4 mb-4">
                <span className="text-xs font-bold text-orange-400 uppercase tracking-wider">
                  Fastest Way to Reach Us
                </span>
                <span className="text-[11px] text-slate-400">Average response: &lt; 15 mins</span>
              </div>

              <h3 className="text-xl font-bold text-white mb-2">
                Chat Directly on WhatsApp
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                Send us a message with your business idea or existing website link. We can discuss your needs in English or Kiswahili.
              </p>

              <button
                onClick={handleDirectWhatsApp}
                className="w-full py-3.5 px-5 rounded-xl text-sm font-bold text-white bg-orange-500 hover:bg-orange-600 active:bg-orange-700 shadow-lg hover:shadow-orange-500/20 transition-all flex items-center justify-center gap-2.5 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Open WhatsApp ({AGENCY_CONFIG.phoneDisplay})</span>
              </button>
            </div>

            {/* Placeholder Details with Quick-Copy */}
            <div className="p-6 rounded-2xl bg-navy-950/60 dark:bg-navy-900/60 border border-navy-800 space-y-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Direct Agency Contacts (Placeholder Details)
              </h4>

              {/* Phone 1 */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-navy-900 dark:bg-navy-850 border border-navy-800 dark:border-navy-750 text-xs">
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-orange-400 shrink-0" />
                  <div>
                    <span className="text-slate-400 block text-[10px]">Primary / WhatsApp</span>
                    <span className="text-white font-mono font-medium">{AGENCY_CONFIG.phoneDisplay}</span>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(AGENCY_CONFIG.phoneDisplay, 'phone1')}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-navy-800 rounded transition-colors cursor-pointer"
                  title="Copy Phone Number"
                >
                  {copiedField === 'phone1' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Phone 2 */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-navy-900 dark:bg-navy-850 border border-navy-800 dark:border-navy-750 text-xs">
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-orange-400 shrink-0" />
                  <div>
                    <span className="text-slate-400 block text-[10px]">Alternative Line</span>
                    <span className="text-white font-mono font-medium">{AGENCY_CONFIG.phoneAltDisplay}</span>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(AGENCY_CONFIG.phoneAltDisplay, 'phone2')}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-navy-800 rounded transition-colors cursor-pointer"
                  title="Copy Phone Number"
                >
                  {copiedField === 'phone2' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Email */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-navy-900 dark:bg-navy-850 border border-navy-800 dark:border-navy-750 text-xs">
                <div className="flex items-center gap-3 min-w-0">
                  <Mail className="w-4 h-4 text-orange-400 shrink-0" />
                  <div className="min-w-0">
                    <span className="text-slate-400 block text-[10px]">Email Inquiries</span>
                    <span className="text-white font-mono font-medium truncate block">{AGENCY_CONFIG.email}</span>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(AGENCY_CONFIG.email, 'email')}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-navy-800 rounded transition-colors cursor-pointer shrink-0"
                  title="Copy Email Address"
                >
                  {copiedField === 'email' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Location */}
              <div className="flex items-start gap-3 p-3 rounded-xl bg-navy-900 dark:bg-navy-850 border border-navy-800 dark:border-navy-750 text-xs">
                <MapPin className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 block text-[10px]">Office & Studio</span>
                  <span className="text-white leading-relaxed">{AGENCY_CONFIG.physicalAddress}</span>
                </div>
              </div>

              {/* Working Hours */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-navy-900 dark:bg-navy-850 border border-navy-800 dark:border-navy-750 text-xs">
                <Clock className="w-4 h-4 text-orange-400 shrink-0" />
                <div>
                  <span className="text-slate-400 block text-[10px]">Working Hours</span>
                  <span className="text-white">{AGENCY_CONFIG.workingHours}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Proposal Request Form */}
          <div className="lg:col-span-7 bg-white dark:bg-navy-950 rounded-2xl p-6 sm:p-8 lg:p-10 shadow-xl border border-slate-200 dark:border-navy-800 transition-colors">
            {!submitted ? (
              <form onSubmit={handleFormSubmit} className="space-y-5">
                <div>
                  <h3 className="text-xl font-bold text-navy-900 dark:text-white mb-1">
                    Request a Free Project Proposal
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                    Tell us about your business goals. We typically respond within 24 hours.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                      Your Full Name <span className="text-orange-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Juma Rashid"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full text-xs sm:text-sm p-3 bg-white dark:bg-navy-900 border border-slate-300 dark:border-navy-750 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                      Company / Business Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Serengeti Tours or Coastal Café"
                      value={formData.businessName}
                      onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                      className="w-full text-xs sm:text-sm p-3 bg-white dark:bg-navy-900 border border-slate-300 dark:border-navy-750 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                      Phone / WhatsApp Number <span className="text-orange-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 0710 841 854"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full text-xs sm:text-sm p-3 bg-white dark:bg-navy-900 border border-slate-300 dark:border-navy-750 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                      Service of Interest
                    </label>
                    <select
                      value={formData.service}
                      onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                      className="w-full text-xs sm:text-sm p-3 bg-white dark:bg-navy-900 border border-slate-300 dark:border-navy-750 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    >
                      <option>Business Websites (From TZS 450,000)</option>
                      <option>Restaurant & Café Websites (From TZS 650,000)</option>
                      <option>Hotel & Resort Websites (From TZS 950,000)</option>
                      <option>Online Catalogues (From TZS 800,000)</option>
                      <option>Website Maintenance (TZS 120,000 / month)</option>
                      <option>Custom Enterprise Development</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                    Estimated Budget in Tanzanian Shillings
                  </label>
                  <select
                    value={formData.budgetRange}
                    onChange={(e) => setFormData({ ...formData, budgetRange: e.target.value })}
                    className="w-full text-xs sm:text-sm p-3 bg-white dark:bg-navy-900 border border-slate-300 dark:border-navy-750 text-slate-900 dark:text-white rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  >
                    <option>TZS 450,000 – TZS 650,000 (Starter)</option>
                    <option>TZS 650,000 – TZS 950,000 (Standard)</option>
                    <option>TZS 950,000 – TZS 1,800,000 (Hospitality & Catalog)</option>
                    <option>TZS 1,800,000+ (Custom Enterprise)</option>
                    <option>Monthly Care Plan Only (TZS 120,000/mo)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                    Project Details / What do you want your website to do?
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Briefly describe your business, key pages needed, or any specific features like menu booking or catalog..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full text-xs sm:text-sm p-3 bg-white dark:bg-navy-900 border border-slate-300 dark:border-navy-750 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  />
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                  <button
                    type="submit"
                    className="w-full sm:flex-1 py-3 px-5 text-xs font-bold text-white bg-navy-900 dark:bg-navy-800 hover:bg-navy-800 dark:hover:bg-navy-750 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm border dark:border-navy-700"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Proposal Request</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleForwardToWhatsApp}
                    className="w-full sm:w-auto py-3 px-4 text-xs font-bold text-orange-600 dark:text-orange-400 hover:text-orange-700 dark:hover:text-orange-300 bg-orange-50 dark:bg-orange-500/10 hover:bg-orange-100 dark:hover:bg-orange-500/20 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer border border-transparent dark:border-orange-500/30"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Send via WhatsApp Instead</span>
                  </button>
                </div>
              </form>
            ) : (
              <div className="py-8 text-center space-y-4">
                <div className="w-14 h-14 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <Check className="w-8 h-8 stroke-[3]" />
                </div>
                <h4 className="text-xl font-bold text-navy-900 dark:text-white">
                  Asante Sana, {formData.fullName}!
                </h4>
                <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto leading-relaxed">
                  Your inquiry for <strong>{formData.service}</strong> has been logged. Our Kigamboni team will review your requirements and reach out via phone or WhatsApp at <strong>{formData.phone}</strong>.
                </p>

                <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                  <button
                    onClick={handleForwardToWhatsApp}
                    className="w-full sm:w-auto px-5 py-3 text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Send to Arnold on WhatsApp (+255 710 841 854)</span>
                  </button>

                  <button
                    onClick={handleSendEmail}
                    className="w-full sm:w-auto px-5 py-3 text-xs font-bold text-navy-900 dark:text-white bg-slate-100 dark:bg-navy-800 hover:bg-slate-200 dark:hover:bg-navy-750 border border-slate-300 dark:border-navy-700 rounded-xl shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Mail className="w-4 h-4 text-orange-500" />
                    <span>Send Email (arnoldblcksses@gmail.com)</span>
                  </button>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        fullName: '',
                        businessName: '',
                        phone: '',
                        service: 'Business Websites',
                        budgetRange: 'TZS 450,000 – TZS 950,000',
                        message: '',
                      });
                    }}
                    className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white underline cursor-pointer"
                  >
                    Submit Another Request
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
