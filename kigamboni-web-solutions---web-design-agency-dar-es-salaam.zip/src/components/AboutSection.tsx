import React from 'react';
import { MapPin, Smartphone, ShieldCheck, HeartHandshake, Zap, Compass, CheckCircle2 } from 'lucide-react';
import { AGENCY_CONFIG } from '../data/agencyData';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 lg:py-28 bg-slate-50 dark:bg-navy-950 border-b border-slate-200 dark:border-navy-850 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Narrative & Values */}
          <div className="lg:col-span-7">
            <div className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-3">
              04. About Our Agency
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-navy-900 dark:text-white tracking-tight mb-6 [text-wrap:balance]">
              Rooted in Kigamboni, Engineering Websites for Tanzania’s Thriving Economy
            </h2>

            <div className="space-y-4 text-slate-700 dark:text-slate-300 text-sm sm:text-base leading-relaxed mb-8">
              <p>
                <strong>KIGAMBONI WEB SOLUTIONS</strong> was founded with a singular, resolute mission: to give Tanzanian businesses, hotels, restaurants, and retail entrepreneurs websites that actually produce measurable revenue, not just look like decorative flyers.
              </p>
              <p>
                From our studio situated right here along the coastal hub of Kigamboni in Dar es Salaam, we design with deep cultural and economic context. We know that in Tanzania, over <strong>80% of your potential customers will browse your site using budget or mid-range Android smartphones</strong> connected to mobile data (Vodacom, Airtel, Tigo, and Halotel). If a website takes 8 seconds to load heavy uncompressed graphics, that visitor bounces.
              </p>
              <p>
                That is why every site we engineer is lightweight, blazing-fast, and integrated directly with WhatsApp—the heartbeat of Tanzanian commerce.
              </p>
            </div>

            {/* Core Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-white dark:bg-navy-900 rounded-xl border border-slate-200 dark:border-navy-800">
                <div className="flex items-center gap-2 text-xs font-bold text-navy-900 dark:text-white mb-1.5">
                  <Smartphone className="w-4 h-4 text-orange-500" />
                  <span>Mobile & Android First</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-normal">
                  Tested across Samsung, Tecno, Infinix, and Xiaomi devices to guarantee fluid responsiveness and minimal bundle data usage.
                </p>
              </div>

              <div className="p-4 bg-white dark:bg-navy-900 rounded-xl border border-slate-200 dark:border-navy-800">
                <div className="flex items-center gap-2 text-xs font-bold text-navy-900 dark:text-white mb-1.5">
                  <HeartHandshake className="w-4 h-4 text-orange-500" />
                  <span>Direct WhatsApp Commerce</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-normal">
                  We turn traffic into immediate buyer conversations with one-tap WhatsApp messages with pre-filled orders.
                </p>
              </div>

              <div className="p-4 bg-white dark:bg-navy-900 rounded-xl border border-slate-200 dark:border-navy-800">
                <div className="flex items-center gap-2 text-xs font-bold text-navy-900 dark:text-white mb-1.5">
                  <ShieldCheck className="w-4 h-4 text-orange-500" />
                  <span>Zero Hostage Code</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-normal">
                  You own your domain, files, and graphics completely. We do not trap you in exorbitant recurring proprietary systems.
                </p>
              </div>

              <div className="p-4 bg-white dark:bg-navy-900 rounded-xl border border-slate-200 dark:border-navy-800">
                <div className="flex items-center gap-2 text-xs font-bold text-navy-900 dark:text-white mb-1.5">
                  <MapPin className="w-4 h-4 text-orange-500" />
                  <span>Local Accountability</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-normal">
                  Real designers and developers in Dar es Salaam you can meet, call, and speak with in English or Kiswahili.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Location & Commitment Card */}
          <div className="lg:col-span-5">
            <div className="bg-navy-900 dark:bg-navy-900/90 text-white rounded-2xl p-6 sm:p-8 border border-navy-800 dark:border-navy-750 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center gap-2 text-xs font-semibold text-orange-400 uppercase tracking-wider mb-4">
                <Compass className="w-4 h-4" />
                <span>Our Dar es Salaam Presence</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold mb-3 text-white">
                Located in Kigamboni, Serving Clients Countrywide
              </h3>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                Whether your business is located right here in Kigamboni, across the Nyerere Bridge in Posta, Kariakoo, Masaki, Mikocheni, or upcountry in Arusha, Mwanza, Dodoma, or Zanzibar, we collaborate seamlessly via WhatsApp, Google Meet, and phone.
              </p>

              <div className="space-y-3 pt-4 border-t border-navy-800 text-xs text-slate-300">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                  <span>{AGENCY_CONFIG.physicalAddress}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
                  <span>Official working language: English & Kiswahili</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
                  <span>Hours: {AGENCY_CONFIG.workingHours}</span>
                </div>
              </div>

              {/* Swahili quote */}
              <div className="mt-6 p-4 rounded-xl bg-navy-950/70 border border-navy-800 text-xs italic text-slate-300">
                "Tunajenga tovuti zinazoleta wateja wa kweli kwenye biashara yako kupitia simu za mkononi na WhatsApp."
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
