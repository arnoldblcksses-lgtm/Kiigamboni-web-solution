import React, { useState } from 'react';
import { Check, MessageSquare, ArrowRight, Calculator, ShieldCheck, HelpCircle } from 'lucide-react';
import { PRICING_PLANS, MAINTENANCE_PLAN, AGENCY_CONFIG } from '../data/agencyData';

interface PricingSectionProps {
  onOpenPublishingGuide: () => void;
  preselectedService?: string;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onOpenPublishingGuide }) => {
  const [activeTab, setActiveTab] = useState<'packages' | 'calculator'>('packages');

  // Calculator State
  const [projectType, setProjectType] = useState<'business' | 'restaurant' | 'hotel' | 'catalogue' | 'custom'>('business');
  const [pageRange, setPageRange] = useState<'standard' | 'medium' | 'large'>('standard');
  const [includeBilingual, setIncludeBilingual] = useState(false);
  const [includeWhatsAppFlow, setIncludeWhatsAppFlow] = useState(true);
  const [includeLocalSEO, setIncludeLocalSEO] = useState(true);
  const [includeMaintenance, setIncludeMaintenance] = useState(false);

  // Calculate dynamic quote in TZS
  const calculateTotalTZS = () => {
    let base = 450000;
    if (projectType === 'restaurant') base = 650000;
    if (projectType === 'catalogue') base = 800000;
    if (projectType === 'hotel') base = 950000;
    if (projectType === 'custom') base = 1500000;

    let pageCost = 0;
    if (pageRange === 'medium') pageCost = 150000;
    if (pageRange === 'large') pageCost = 350000;

    let extras = 0;
    if (includeBilingual) extras += 150000;
    if (includeWhatsAppFlow) extras += 80000;
    if (includeLocalSEO) extras += 90000;
    if (includeMaintenance) extras += 120000;

    return base + pageCost + extras;
  };

  const handlePackageWhatsApp = (planName: string, priceTZS: number) => {
    const text = encodeURIComponent(
      `Habari Kigamboni Web Solutions! I am interested in your "${planName}" package for TZS ${priceTZS.toLocaleString()}. Let's discuss requirements for my website.`
    );
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  const handleCalculatorWhatsApp = () => {
    const total = calculateTotalTZS();
    const details = `Type: ${projectType}, Pages: ${pageRange}, Bilingual: ${includeBilingual ? 'Yes' : 'No'}, WhatsApp Funnel: ${includeWhatsAppFlow ? 'Yes' : 'No'}, Local SEO: ${includeLocalSEO ? 'Yes' : 'No'}, Monthly Care: ${includeMaintenance ? 'Yes' : 'No'}`;
    const text = encodeURIComponent(
      `Habari! I created an estimate on your website cost calculator.\nTotal Estimate: TZS ${total.toLocaleString()}.\nConfiguration: ${details}.\nCan we schedule a call to proceed?`
    );
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="pricing" className="py-20 lg:py-28 bg-white dark:bg-navy-900 border-b border-slate-200 dark:border-navy-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <div className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-3">
              03. Transparent Investment (TZS)
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-navy-900 dark:text-white tracking-tight mb-3 [text-wrap:balance]">
              Transparent Pricing in Tanzanian Shillings
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              No hidden currency exchange surprises, no mandatory monthly dollar subscriptions, and zero vendor lock-in. You own your code and assets 100%.
            </p>
          </div>

          {/* Toggle between Fixed Packages and Custom Calculator */}
          <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 dark:bg-navy-950 rounded-xl border border-slate-200 dark:border-navy-800 self-start md:self-auto text-xs shrink-0">
            <button
              onClick={() => setActiveTab('packages')}
              className={`px-4 py-2 font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === 'packages'
                  ? 'bg-navy-900 dark:bg-navy-800 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-navy-900 dark:hover:text-white'
              }`}
            >
              Fixed Packages
            </button>
            <button
              onClick={() => setActiveTab('calculator')}
              className={`px-4 py-2 font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'calculator' ? 'bg-orange-500 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-navy-900 dark:hover:text-white'
              }`}
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>Project Cost Calculator</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Packages Grid */}
        {activeTab === 'packages' && (
          <div className="space-y-12">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
              {PRICING_PLANS.map((plan) => (
                <div
                  key={plan.id}
                  className={`rounded-2xl p-6 sm:p-8 flex flex-col justify-between transition-all relative ${
                    plan.popular
                      ? 'bg-navy-900 dark:bg-navy-850 text-white shadow-xl ring-2 ring-orange-500 scale-100 lg:-translate-y-2'
                      : 'bg-slate-50 dark:bg-navy-950/70 border border-slate-200 dark:border-navy-800 text-slate-900 dark:text-slate-100'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-orange-500 text-white text-[11px] font-extrabold uppercase tracking-widest px-3.5 py-1 rounded-full shadow-sm">
                      Recommended for Most Businesses
                    </div>
                  )}

                  <div>
                    {/* Header */}
                    <div className="mb-6">
                      <h3 className={`text-xl font-bold mb-1 ${plan.popular ? 'text-white' : 'text-navy-900 dark:text-white'}`}>
                        {plan.name}
                      </h3>
                      <p className={`text-xs min-h-[36px] ${plan.popular ? 'text-slate-300' : 'text-slate-500 dark:text-slate-400'}`}>
                        {plan.idealFor}
                      </p>
                    </div>

                    {/* Price in Tanzanian Shillings */}
                    <div className="mb-6 pb-6 border-b border-slate-200/20 dark:border-navy-800">
                      <div className="flex items-baseline gap-1">
                        <span className={`text-xs font-semibold uppercase ${plan.popular ? 'text-orange-400' : 'text-slate-500 dark:text-slate-400'}`}>
                          TZS
                        </span>
                        <span className="text-3xl sm:text-4xl font-extrabold tabular-nums tracking-tight">
                          {plan.priceTZS.toLocaleString()}
                        </span>
                      </div>
                      <span className={`text-xs block mt-1 ${plan.popular ? 'text-slate-300' : 'text-slate-500 dark:text-slate-400'}`}>
                        One-time project investment · Turnaround: <strong>{plan.turnaround}</strong>
                      </span>
                    </div>

                    {/* Features list */}
                    <div className="space-y-3 mb-8">
                      <span className={`text-xs font-bold uppercase tracking-wider block ${plan.popular ? 'text-orange-400' : 'text-navy-900 dark:text-white'}`}>
                        Package Deliverables:
                      </span>
                      {plan.features.map((feature, i) => (
                        <div key={i} className="flex items-start gap-2.5 text-xs">
                          <Check
                            className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${
                              plan.popular ? 'text-orange-400' : 'text-orange-600 dark:text-orange-400'
                            }`}
                          />
                          <span className={plan.popular ? 'text-slate-200' : 'text-slate-700 dark:text-slate-300'}>
                            {feature}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Card Action */}
                  <div className="pt-4 border-t border-slate-200/20 dark:border-navy-800">
                    <button
                      onClick={() => handlePackageWhatsApp(plan.name, plan.priceTZS)}
                      className={`w-full py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm ${
                        plan.popular
                          ? 'bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white'
                          : 'bg-navy-900 dark:bg-navy-800 hover:bg-navy-800 dark:hover:bg-navy-750 text-white border dark:border-navy-700'
                      }`}
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Choose {plan.name}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Maintenance & Support Plan Banner */}
            <div className="bg-slate-900 dark:bg-navy-950 rounded-2xl p-6 sm:p-8 text-white border border-navy-800 dark:border-navy-850 flex flex-col lg:flex-row items-center justify-between gap-6 shadow-md">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-orange-500 text-white rounded-xl shrink-0">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-lg sm:text-xl font-bold text-white">
                      {MAINTENANCE_PLAN.name}
                    </h3>
                    <span className="text-xs bg-navy-800 text-orange-400 font-bold px-2.5 py-0.5 rounded">
                      Optional Monthly Care
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mb-3">
                    {MAINTENANCE_PLAN.description}
                  </p>
                  <div className="flex flex-wrap gap-x-5 gap-y-1.5 text-xs text-slate-400">
                    {MAINTENANCE_PLAN.features.slice(0, 3).map((f, idx) => (
                      <span key={idx} className="flex items-center gap-1.5">
                        <Check className="w-3 h-3 text-orange-400" />
                        <span>{f}</span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row lg:flex-col items-center sm:items-end gap-3 shrink-0 w-full sm:w-auto">
                <div className="text-center sm:text-right">
                  <span className="text-2xl font-extrabold text-white tabular-nums">
                    TZS {MAINTENANCE_PLAN.priceTZS.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-400 block">/ Month</span>
                </div>
                <button
                  onClick={() => handlePackageWhatsApp(MAINTENANCE_PLAN.name, MAINTENANCE_PLAN.priceTZS)}
                  className="w-full sm:w-auto px-5 py-2.5 text-xs font-bold text-navy-950 bg-white hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  Add Website Maintenance
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Interactive Project Cost Calculator */}
        {activeTab === 'calculator' && (
          <div className="bg-slate-50 dark:bg-navy-950/70 border border-slate-200 dark:border-navy-800 rounded-2xl p-6 sm:p-8 lg:p-10 shadow-sm max-w-4xl mx-auto transition-colors">
            <div className="mb-8 pb-6 border-b border-slate-200 dark:border-navy-800">
              <span className="text-xs font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider block mb-1">
                Custom Web Estimate Calculator
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-navy-900 dark:text-white">
                Tailor Your Project Scope & Get Instant TZS Pricing
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1">
                Select your industry requirements below to calculate an exact project estimate.
              </p>
            </div>

            <div className="space-y-8">
              {/* Step 1: Project Type */}
              <div>
                <label className="block text-xs font-bold text-navy-900 dark:text-white uppercase tracking-wider mb-3">
                  1. What type of website do you need?
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { id: 'business', label: 'Business Website', price: '450k' },
                    { id: 'restaurant', label: 'Restaurant & Café', price: '650k' },
                    { id: 'hotel', label: 'Hotel & Resort', price: '950k' },
                    { id: 'catalogue', label: 'Online Catalogue', price: '800k' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setProjectType(item.id as any)}
                      className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                        projectType === item.id
                          ? 'bg-navy-900 dark:bg-navy-800 border-navy-900 dark:border-orange-500 text-white font-bold shadow-sm'
                          : 'bg-white dark:bg-navy-900 border-slate-200 dark:border-navy-800 text-slate-800 dark:text-slate-200 hover:border-slate-300 dark:hover:border-navy-700'
                      }`}
                    >
                      <span className="block text-xs font-bold truncate">{item.label}</span>
                      <span className={`text-[11px] block mt-1 ${projectType === item.id ? 'text-orange-400' : 'text-slate-500 dark:text-slate-400'}`}>
                        From TZS {item.price}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Page Scope */}
              <div>
                <label className="block text-xs font-bold text-navy-900 dark:text-white uppercase tracking-wider mb-3">
                  2. Approximate number of pages or sections:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { id: 'standard', label: 'Up to 5 Pages', detail: 'Home, About, Services, Gallery, Contact' },
                    { id: 'medium', label: '6 - 10 Pages (+TZS 150k)', detail: 'Individual service pages, menus, catalog' },
                    { id: 'large', label: '11 - 20+ Pages (+TZS 350k)', detail: 'Large product line, multi-branch, blog' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      onClick={() => setPageRange(p.id as any)}
                      className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                        pageRange === p.id
                          ? 'bg-navy-900 dark:bg-navy-800 border-navy-900 dark:border-orange-500 text-white font-bold shadow-sm'
                          : 'bg-white dark:bg-navy-900 border-slate-200 dark:border-navy-800 text-slate-800 dark:text-slate-200 hover:border-slate-300 dark:hover:border-navy-700'
                      }`}
                    >
                      <span className="block text-xs font-bold">{p.label}</span>
                      <span className={`text-[11px] block mt-1 ${pageRange === p.id ? 'text-slate-300' : 'text-slate-500 dark:text-slate-400'}`}>
                        {p.detail}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 3: Add-on Features */}
              <div>
                <label className="block text-xs font-bold text-navy-900 dark:text-white uppercase tracking-wider mb-3">
                  3. Select optional custom features:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className="flex items-center gap-3 p-3.5 bg-white dark:bg-navy-900 border border-slate-200 dark:border-navy-800 rounded-xl cursor-pointer hover:border-slate-300 dark:hover:border-navy-700">
                    <input
                      type="checkbox"
                      checked={includeWhatsAppFlow}
                      onChange={(e) => setIncludeWhatsAppFlow(e.target.checked)}
                      className="w-4 h-4 text-orange-500 rounded border-slate-300 dark:border-navy-700 focus:ring-orange-500"
                    />
                    <div className="text-xs">
                      <span className="font-bold text-slate-900 dark:text-white block">WhatsApp Click-to-Order Automation</span>
                      <span className="text-slate-500 dark:text-slate-400">+TZS 80,000 (Pre-fills item name & price into WhatsApp)</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-3.5 bg-white dark:bg-navy-900 border border-slate-200 dark:border-navy-800 rounded-xl cursor-pointer hover:border-slate-300 dark:hover:border-navy-700">
                    <input
                      type="checkbox"
                      checked={includeBilingual}
                      onChange={(e) => setIncludeBilingual(e.target.checked)}
                      className="w-4 h-4 text-orange-500 rounded border-slate-300 dark:border-navy-700 focus:ring-orange-500"
                    />
                    <div className="text-xs">
                      <span className="font-bold text-slate-900 dark:text-white block">Bilingual Language Switch (English & Kiswahili)</span>
                      <span className="text-slate-500 dark:text-slate-400">+TZS 150,000 (Ideal for local & international customers)</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-3.5 bg-white dark:bg-navy-900 border border-slate-200 dark:border-navy-800 rounded-xl cursor-pointer hover:border-slate-300 dark:hover:border-navy-700">
                    <input
                      type="checkbox"
                      checked={includeLocalSEO}
                      onChange={(e) => setIncludeLocalSEO(e.target.checked)}
                      className="w-4 h-4 text-orange-500 rounded border-slate-300 dark:border-navy-700 focus:ring-orange-500"
                    />
                    <div className="text-xs">
                      <span className="font-bold text-slate-900 dark:text-white block">Google Maps & Dar es Salaam Local SEO</span>
                      <span className="text-slate-500 dark:text-slate-400">+TZS 90,000 (Helps local customers find you on Google)</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-3.5 bg-white dark:bg-navy-900 border border-slate-200 dark:border-navy-800 rounded-xl cursor-pointer hover:border-slate-300 dark:hover:border-navy-700">
                    <input
                      type="checkbox"
                      checked={includeMaintenance}
                      onChange={(e) => setIncludeMaintenance(e.target.checked)}
                      className="w-4 h-4 text-orange-500 rounded border-slate-300 dark:border-navy-700 focus:ring-orange-500"
                    />
                    <div className="text-xs">
                      <span className="font-bold text-slate-900 dark:text-white block">First Month Website Maintenance Included</span>
                      <span className="text-slate-500 dark:text-slate-400">+TZS 120,000 (Backups, speed checks & content updates)</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* Real-time Calculation Summary Box */}
              <div className="p-6 bg-navy-900 dark:bg-navy-850 text-white rounded-xl flex flex-col sm:flex-row items-center justify-between gap-6 border dark:border-navy-750">
                <div>
                  <span className="text-xs uppercase tracking-widest text-orange-400 font-bold block mb-1">
                    Estimated Project Investment
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-sm font-semibold text-slate-300">TZS</span>
                    <span className="text-3xl sm:text-4xl font-extrabold tabular-nums tracking-tight text-white">
                      {calculateTotalTZS().toLocaleString()}
                    </span>
                  </div>
                  <span className="text-xs text-slate-400 mt-1 block">
                    Includes responsive design, Android optimization, domain setup & WhatsApp integration.
                  </span>
                </div>

                <button
                  onClick={handleCalculatorWhatsApp}
                  className="w-full sm:w-auto px-6 py-3.5 text-xs font-bold text-white bg-orange-500 hover:bg-orange-600 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Order This Scope on WhatsApp</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
