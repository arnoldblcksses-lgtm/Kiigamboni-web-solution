import React from 'react';
import { ArrowRight, MessageSquare, Smartphone, Zap, Shield, MapPin } from 'lucide-react';
import { AGENCY_CONFIG } from '../data/agencyData';

interface HeroProps {
  onOpenCalculator: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenCalculator }) => {
  const handleWhatsAppClick = () => {
    const text = encodeURIComponent('Habari Kigamboni Web Solutions! I saw your agency website and would like a quote for a new website.');
    window.open(`https://wa.me/${AGENCY_CONFIG.phoneRaw}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section className="relative bg-navy-900 text-white pt-12 pb-20 lg:pt-20 lg:pb-28 overflow-hidden">
      {/* Background subtle atmospheric gradient */}
      <div className="absolute inset-0 bg-radial-at-t from-navy-800/40 via-navy-900 to-navy-950 pointer-events-none" />
      
      {/* Subtle geometric line pattern */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px]" 
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Core Value Proposition */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Location & Trust marker (Clean text, no pill box) */}
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-orange-400 uppercase mb-4">
              <MapPin className="w-3.5 h-3.5" />
              <span>Kigamboni · Dar es Salaam · Tanzania</span>
            </div>

            {/* Mandatory Main Heading */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[3.5rem] font-extrabold text-white tracking-tight leading-[1.12] mb-6 [text-wrap:balance]">
              We Build Websites That Grow Your Business.
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mb-8">
              Empower your Tanzanian company with a fast, modern, mobile-friendly website. From luxury beach resorts and popular Swahili grills to corporate firms and online product catalogues, we craft websites engineered to generate real inquiries and paying clients.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 mb-10">
              <a
                href="#pricing"
                className="px-6 py-3.5 text-sm font-bold text-white bg-orange-500 hover:bg-orange-600 active:bg-orange-700 rounded-lg shadow-lg hover:shadow-orange-500/20 transition-all text-center flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
              >
                <span>View Pricing & Packages</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <button
                onClick={handleWhatsAppClick}
                className="px-6 py-3.5 text-sm font-semibold text-slate-100 bg-navy-800 hover:bg-navy-750 border border-navy-700 hover:border-slate-600 rounded-lg transition-all text-center flex items-center justify-center gap-2.5 whitespace-nowrap cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>Chat on WhatsApp</span>
              </button>

              <button
                onClick={onOpenCalculator}
                className="px-4 py-3.5 text-xs font-semibold text-orange-400 hover:text-orange-300 hover:bg-navy-850/60 rounded-lg border border-orange-500/30 transition-all text-center whitespace-nowrap"
              >
                Calculate Cost in TZS
              </button>
            </div>

            {/* Trust highlights */}
            <div className="pt-6 border-t border-navy-800/80 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-orange-400 shrink-0" />
                <span>Android & Mobile First</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-orange-400 shrink-0" />
                <span>Rapid 7–14 Day Delivery</span>
              </div>
              <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
                <Shield className="w-4 h-4 text-orange-400 shrink-0" />
                <span>100% Code Ownership</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Studio Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-navy-700/80 bg-navy-950 group">
              <img
                src={AGENCY_CONFIG.heroImage}
                alt="Kigamboni Web Solutions modern creative workspace in Dar es Salaam"
                className="w-full h-[320px] sm:h-[400px] lg:h-[440px] object-cover transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/40 to-transparent" />

              {/* Floating Overlay Content */}
              <div className="absolute bottom-0 inset-x-0 p-5 text-white">
                <div className="text-xs font-medium text-orange-400 mb-1 flex items-center gap-1.5">
                  <span>Demonstration Studio Showcase</span>
                  <span>·</span>
                  <span>Kigamboni, Dar</span>
                </div>
                <p className="text-sm font-bold text-white mb-2">
                  Tailored Web Engineering for Tanzanian Commerce
                </p>
                <div className="text-xs text-slate-300 flex items-center justify-between pt-2 border-t border-white/10">
                  <span>Fast Vodacom / Tigo / Airtel load speeds</span>
                  <a href="#portfolio" className="text-orange-300 hover:text-white font-medium inline-flex items-center gap-1">
                    See Demos <ArrowRight className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>

            {/* Quick stats floating card */}
            <div className="mt-4 p-4 rounded-xl bg-navy-850 border border-navy-700 flex items-center justify-between text-xs text-slate-300">
              <div>
                <span className="block text-white font-bold text-sm">TZS 450,000</span>
                <span>Starting package price</span>
              </div>
              <div className="h-6 w-px bg-navy-700" />
              <div>
                <span className="block text-white font-bold text-sm">Direct WhatsApp</span>
                <span>Customer lead funnel</span>
              </div>
              <div className="h-6 w-px bg-navy-700" />
              <div>
                <span className="block text-white font-bold text-sm">Kigamboni</span>
                <span>Local Dar es Salaam team</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
